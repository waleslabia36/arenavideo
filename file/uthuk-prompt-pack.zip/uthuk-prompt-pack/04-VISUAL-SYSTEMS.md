# 04 — Visual systems

Pick one system per video (file 03). Do not mix a pastel field with a dark-red glow. You may use the system's second field color for a section shift. Chrome (brand chip, caption skin, grid-or-mesh) stays in the system the whole time.

All systems share:

- 30 fps.
- Safe margin 7% of the short side.
- Cards: radius 22–28, shadow `0 18px 50px rgba(16,20,18,0.12)` on light fields, `0 20px 60px rgba(0,0,0,0.35)` on dark fields.
- Entrance: spring, damping 14, stiffness 180, mass 0.6. Opacity reaches 1 by frame 6. Translate Y from 16 to 0. Do not use linear fades as the only motion.
- Exit: 8 frames, opacity to 0, scale to 0.96, Y +8.
- Section replace may add `filter: blur(8px)` on the outgoing group for those 8 frames. Incoming group is sharp.
- Bengali and Latin share one family for body: Noto Sans Bengali. English display pills may use Inter, weight 700–800, tracking 0.04em.
- Never outline text with the default text-stroke in a way that breaks Bengali marks. Outlined display words are Latin keywords only (`LEADS`, `FREE`).
- Icons are original inline SVG, 1.75 stroke, round caps. No emoji as the main icon. No remote images.

## green-brand

Used by v1. Personal pitch. "আপনি…"

- Field: `#087B3C`. Grid lines `#066432` at 48px, 1px, opacity 0.45. Two soft blooms, `#2EBE62` at 20% opacity, 40% size, drifting 30px over the whole video.
- Second field, for a section shift: `#184E9A`, grid `#123E7C`, blooms `#3C7FE0`.
- Text on field: `#FFFFFF`.
- Keyword highlight / outline / caption bar: `#D8FF4A`.
- Pills: white `#FFFFFF`, text `#101412`, radius 999, height 54–64 on 1080-wide (scale with width). A 28px icon circle in `#087B3C` or `#D8FF4A`.
- Black pill: `#101412` background, white text. Used for one hard word per idea (`SHORTCUT`).
- Cards: white, text `#101412`.
- Brand chip: white pill, centered top, 18px from the safe top. Green rounded square 22px with a white "M" or a simple clapper, then `MARKET X BANGLA` in Inter 700, 13px, tracking 0.08em.
- Caption skin: a lime bar along the bottom safe area, text `#101412`, Noto Sans Bengali 700, 28px on 1080×1920. Radius 16. Not full-bleed.
- End: fade field to `#04140A`.

## pastel

Used by v3. Product roundup on a light field.

- Field: `#F4F7FB`. Two radials: `#D7E6FF` top-left, `#F8D7E8` bottom-right, both 55% size, opacity 0.9. No grid, or a white grid at 4% opacity.
- Text: `#16181D`.
- Accent: `#2563EB`. Second accents for icon tiles only: `#0F766E`, `#DB2777`, `#EA580C`, `#4F46E5`. One tile color per card, rotating.
- Keyword in a sentence: `#2563EB`, not lime.
- Cards: white, border `1px solid rgba(15,23,42,0.06)`.
- Price pills: `#D8FF4A` text `#101412` for FREE, `#111827` text white for `$0`, `#FEF3C7` text `#92400E` for discounts.
- Header: brand left, kicker right (`AI TOOLS`) in a blue-tint pill.
- Footer: `@marketxbangla` in `#94A3B8`, 14px, centered.
- Caption skin: no lime bar. The current cue is a 15px `#64748B` line under the stage, or omitted when the headline already says it.
- Index numbers `01` `02` in Inter 800, 42px, `#2563EB`.

## light-diagram

Used by v2. How-it-works.

- Field: `#F3F6F4` with a faint mint radial `#DCEFE4`.
- Ink: `#141816`.
- Accent: `#14915A`.
- Diagram: 1.5px strokes `#141816` at 0.7 opacity. Nodes are black rounded squares 56px with white icons, or a white circle with a green ring.
- Concentric rings: 3 strokes, opacity 0.15 / 0.3 / 0.5, center node 88px.
- Bottom sentence: Noto Sans Bengali 600, 32px on 1920×1080, centered. The English word inside it is Inter 700, same size, not a separate pill unless it is a product name.
- Brand chip small, top-left, not a huge pill.
- Caption skin: that bottom sentence is the caption. Do not add a second one.

## dark-red

Used by v4. Industry listicle.

- Field: `#070605`. Red glow `#E11D2E` at 35% opacity, blurred 80px, sitting behind the active card, drifting slowly. Faint grid `#2A1210` at 64px.
- Text: `#F6F4F2`.
- Accent: `#FF2D3A`.
- Second text: `#A39A96`.
- Selection handles: 10px corner brackets, 2px, `#FFFFFF`, around the active title for 30 frames after it enters, then fade. This is a signature. Do not skip it on this theme.
- Index: Inter 800, 64px, white, with the accent only on the number.
- Comparison bar track `#1C1917`, fill `#FF2D3A` vs a dim `#44403C` fill for the other side. Percent labels in Inter 700.
- Caption skin: 18px `#D6D3D1` under the stage, left-aligned with the title, not a box.
- Motion blur on section replace is required here.

## dark-orange

Used by v5. Free-tool walkthrough.

- Field: `#090909`. Orange glow `#FF4D1C` behind the browser, 30% opacity, blur 90px.
- Text: `#F8F5F2`.
- Accent: `#FF4D1C`. Proof tags: `#F5E24B` background, `#1A1406` text, radius 8, Inter 800, 12px, tracking 0.06em. Words: FREE, AI, No sign-up, 100% Free.
- Browser mock: dark chrome `#161616`, traffic dots, address bar, the page inside is light `#F4F1EC` so the tool UI reads. The page changes content at each step cue.
- Bottom chip rail: all list items as pills. Inactive `#1A1A1A` text `#A3A3A3`. Active `#FF4D1C` text white. The rail is visible from the second item onward.
- Cross-out: a paid product name with a 3px accent line animating across it at the negation cue. Bengali `লাগবে না` beside it in accent color.
- End card field stays dark. Four monogram marks. Lime is not used here; accent stays orange. `FREE` may be the yellow tag.

## dark-green

Used by v6. Agent editorial.

- Field: `#062616`. Grid `#0C3D26` at 56px. Lime `#B6F25C`.
- Text: `#F4FFF6`.
- Portrait card: 4:5 rounded 18px, fill `#0E3A24`, monogram in lime, a small index tab `03` in the corner. Name in Noto Sans Bengali 700 beside or under it. Enter on the name's word start.
- Highlight box: 2px lime border, radius 10, padding 8px 12px, around the clause that matters. It draws on (stroke) over 8 frames at that clause's start.
- Selection box also used around a single English product word (`MUSE`).
- Checklist card: dark `#0B2E1C`, rows appear on their word, check in lime.
- Stat: Inter 800, 120px on 1920-wide, lime, with a smaller label under it.
- Prohibition: a white rounded square, a simple app glyph, a lime circle-slash over it, entering on the negation cue.
- Header: name left, kicker right, both 13px tracking 0.12em, uppercase, `#D7FFE4`.
- Caption skin: the spoken line at the bottom in 20px `#E7FFE8`, not a bar.

## pinned-note CTA

Use on green-brand, or as the end card of any theme after you recolor it to that theme's field.

- Giant faded numerals behind everything, 18vw, weight 800, white at 16% opacity, a 2×2 of numbers. If the SRT has no numbers, use 28 29 30 31.
- White note, radius 6, shadow, a red pin `#E23B32` at the top center, slight rotation −1.5deg. Enters with the spring.
- Note text: Noto Sans Bengali 700. One line may be the theme accent color. Max 3 lines.
- Polaroid tucked at the note's bottom-right, rotation 4deg: a simple clapper SVG and the kicker (`AI REELS`).
- This card is a scene of its own. It does not share the stage with a browser mock.

## Atom sizes (1080×1920; scale by `width/1080` on vertical, `width/1920` on horizontal)

- Headline: 84–104px, weight 700, line-height 1.05. Max 2 lines. If longer, drop to 64px.
- Pill text: 18–22px, weight 800, Latin tracking 0.04em.
- Outlined keyword: 92px, weight 800, fill transparent, stroke 2px in the accent. Latin only.
- Supporting Bengali: 28–34px, weight 600, white or ink at 0.92.
- Stat: 72–110px.
- Browser / search / checklist card: width 78% of the safe width, max 640px on vertical, max 860px on horizontal.

## Motion you must actually ship

A viewer scrubbing frame by frame must see:

1. The new object absent on the frame before its word.
2. The new object mid-spring on the next 4–6 frames.
3. The object settled, still present, while the voice continues the same idea.
4. A later object joining it, not replacing it, until a scene break or a mock replacement.
5. A verb causing a change inside a mock (check, fill, click, type), not a new title.

If a frame dump looks like a PowerPoint — everything present from the first frame of the scene — the render is wrong. Rebuild the plan.
