# 05 — Scene grammar

How a cue becomes a picture. Use this when the classifier in file 03 gives you tokens and you have to choose a composition.

## The stage has three layers

1. Field — color, grid or mesh, glow. Never empty.
2. Chrome — brand chip, kicker, optional chip rail, caption. Persistent.
3. Stage — one idea. This is the only layer that replaces.

## Recipes

Pick the first recipe that fits the cue. A scene may start on one recipe and add atoms from later cues without changing recipe, until a replacement rule fires.

### R1 Headline build

When: the scene's first cue is mostly Bengali, no product yet.
Show the first Bengali word or short phrase as the headline at its word start. Following Bengali words in the same cue extend the headline if the line is still short (≤ 4 words). Else they become the supporting line under it.
Latin keywords in the same cue become pills stacked under the headline, each at its own word start.

### R2 Keyword hit

When: a Latin keyword is the point of the cue (`LEADS`, `SHORTCUT`, a tool name).
If the scene is still on R1 and this keyword is the payoff word, fade the headline to 0 and bring the keyword in as outlined display type. One black or accent pill may sit beside it. Do this at the keyword's word start, not at cue start if the keyword is not the first word.

### R3 Browser demo

When: a URL, a product that "you open", or a verb browse/search/click/signup/generate.
Replace the stage with a browser or app card at the verb or URL word start. The URL or product name types in. A cursor clicks the primary button if the cue contains click, start, launch, signup, or ফ্রি.
Badges (`FREE`, credit, `$0`) pop at their own word starts on the card's corner. They do not replace the card.

### R4 Search and deliver

When: search / খুঁজ / browse plus a list of results or the word delivered / সঠিক.
Search field contains the keyword. Result rows appear one per spoken noun, check drawing at that noun. A full-width accent bar `DELIVERED` or the Bengali result word enters at the last row or at the word delivered.

### R5 Collect / progress

When: collect, জমা, credit, a number of leads, a process.
A card with a progress bar and a count-up. The bar fills across the scene. The number lands on its spoken value at the number's word end. Checklist rows tick with each feature word.

### R6 Diagram

When: two or more nouns linked by ধরে, থেকে, সাথে, আর, connect, or a "this becomes that" sentence.
Center node is the first noun. Extra nodes enter at their word starts. Edges draw when the linking word is spoken. Labels are the words themselves, short.

### R7 Numbered item

When: an index is present.
Big index and the name enter together (name at its word, index 4 frames earlier). Selection handles on dark-red and dark-green. On pastel, the index is blue and the name is a card title. The rest of the cue adds inside the card. On dark-orange, also light the matching chip in the rail.
Stay on this item until the next index. Do not introduce the next tool early.

### R8 Comparison

When: বনাম, vs, চেয়ে, a percent next to two names.
Two bars or two columns. The winner's bar fills at the percent word. The loser's bar is dim. Names enter at their own words, before the bars fill.

### R9 People

When: a cue has person-name patterns (two capitalized Latin words, or a known name, or a Bengali name of a public figure the SRT names).
Monogram portrait + name, entering at the name. Do not use a photograph. Several people in one scene arrange in a row, each at their own word. If a product is tied to a person, a line draws from the portrait to a word chip.

### R10 Negation

When: the negation list hits.
Keep the object on screen and mark it: circle-slash, animated strike-through, or the Bengali negation in the accent color beside it. Do not swap to a cheerful new card. The prohibition is the motion.

### R11 Stat

When: the cue is mainly a number.
The number is the stage. Count-up. A short label under it from the surrounding Bengali, entering with the number, not before.

### R12 Two-line lockup

When: a cue has two clauses and the second is the hit (`আপনি অফলাইনে। কাজ চলছে।`).
First clause in white, regular weight. Second clause in accent, heavier, entering at the second clause's start. A highlight box may draw around the second clause.

### R13 Chat type

When: the cue is a prompt the user would type, or it contains "বলবেন", "লিখুন", "prompt".
A chat or input card. Characters reveal across the cue. A caret blinks. Do not show the full prompt on frame 1 of the cue.

### R14 Chip rail walkthrough

When: theme is dark-orange, or the SRT is a list of sites/tools longer than 3.
After the first item, the rail is permanent. The stage is a browser. Each new index replaces the page inside the browser, not the rail.

### R15 Pinned note

When: the cue is a CTA (দেখো, সেভ, ফলো, মনে রাখ, আগে) or it is the end card.
Recipe in file 04. One note. One polaroid. No second headline fighting it.

### R16 Follow toggle

When: follow / ফলো.
A social card with the brand. Button reads Follow. At the verb frame it becomes Following and turns accent. That flip is the whole point. Do not start the scene with Following already showing.

## Composition limits

- Max 1 headline, 4 pills, 1 mock, 1 stat on screen at once.
- If a new atom would break the limit, it replaces the oldest atom of the same class (8-frame exit).
- Pills stack vertically on 9:16, wrap in a row on 16:9.
- The mock is centered. Headline sits above the mock only if both are short. If the mock is tall, the headline exits.
- Do not put the caption text inside the mock and in the caption skin. One place.

## Section energy

Copy the reference rhythm:

- 0–2s: one or two words, lots of field. Do not open on a full card.
- Then add one object per spoken beat.
- A mock arrives when the voice starts doing something, not during the hook.
- A color shift happens once or twice in a short video, at a discourse turn.
- The last spoken idea gets a hold, then a fade or a note card. Do not cut off mid-spring.

## Bengali line breaking

Break lines on spaces, never inside a word. Do not hyphenate Bengali. If a headline overflows, reduce the size before you truncate. Never truncate a spoken word. If it still overflows at the minimum size, move the overflow to the supporting line.

## English inside Bengali

When a Latin word sits inside a Bengali sentence and it is not a product name, render it in Inter 700 in the accent color, inline, same baseline. Do not pull it out into a pill unless the classifier called it a keyword and it is a product, a role (`FREELANCER`), or a payoff noun (`LEADS`). Roles and payoff nouns leave the sentence and become pills. Ordinary English adjectives can stay inline.

## Cursor

One cursor on screen at most. It is a small arrow, white with a dark outline, 22px. It moves from the previous point to the target over 8 frames, then a 6px ring expands and fades. It is absent when no verb is active.

## What "matched to the voice" looks like in review

Take any cue. Scrub to 2 frames before its start. The new information in that cue must not be on screen yet. Scrub to 8 frames after the cue's main noun. That noun must be on screen, mid-animation or settled. Scrub to the next cue. The previous noun is either still there (same idea) or leaving (new idea). That is the whole test. File 09 repeats it.
