# 03 — Sync engine

This is the clock. Implement it in plain JavaScript so `scripts/prepare.mjs` can run it without a compiler. The Remotion composition only reads the JSON plan. It does not re-interpret the SRT at render time.

## Parse

Accept SRT and, if they pasted WebVTT, accept that too. Times to milliseconds.

Ignore cue text that is only a note to you:

- A line that is exactly `ASPECT: 9:16` or `ASPECT: 16:9` sets aspect and is not spoken.
- A line that is exactly `THEME: green-brand | pastel | light-diagram | dark-red | dark-orange | dark-green` forces the theme and is not spoken.
- Blank cues are dropped.

If two cues overlap, trust the earlier start and cut it where the next one starts.

## Word clock

SRT cues are line-level. These videos are word-level. Estimate word starts. If a cue already contains word-level timestamps (some exports do, `{...}` or `<time>`), use those instead.

```
tokens = split cue text on whitespace, keep each word
weight(word):
  n = character count, min 1
  if word has A–Z and no Bengali: n *= 1.15
  if word is a number or price: n *= 1.3
  return n

span = cue.end - cue.start
t = cue.start
for word in tokens:
  dur = span * weight(word) / sum(weights)
  word.start = t
  word.end = t + dur
  t = word.end
```

Do not start a visual before `word.start`. A 2-frame lead (66ms) is allowed so the pop lands as the syllable starts. Never more than 4 frames early. Never late by more than 6 frames.

## Split long cues

If a cue is longer than 7.0 seconds, split it into clauses on `।`, `?`, `!`, and `;`. Distribute the cue's time across clauses by character count. Each clause is then word-clocked on its own. This stops a 12-second cue from holding one frozen card.

## Classify every token

Apply in this order. First match wins.

| Test | Class | Visual atom |
| --- | --- | --- |
| index like `01`, `02`, `১`, `প্রথম` | index | big numeral, enters 4 frames before the name it labels |
| price, percent, or a number with 2+ digits, or `24/7`, `1:00` | stat | badge or count-up across the token's own duration |
| `free`, `ফ্রি`, `pro` | badge | pill, color from the theme |
| URL or domain (`manus.im`, anything with a dot and a TLD) | url | browser chrome, URL types across the token duration |
| known action (list below) | verb | trigger the matching UI verb; do not also print the verb as a giant word |
| token is Latin letters, length ≥ 3, no Bengali | keyword | pill, or outlined display word if it is the only keyword in the cue and the cue is short |
| token has Bengali | bangla | part of the headline or the supporting line |
| anything else | skip | do not give it its own object |

Action list (match inside the token, case-insensitive): browse, ব্রাউজ, সার্চ, খুঁজ, search, collect, কালেক্ট, জমা, follow, ফলো, generate, জেনারেট, বানাও, বানান, launch, চালু, signup, সাইন, click, ক্লিক, download, ডাউনলোড, save, সেভ, type, লিখ, compare, তুলনা, send, পাঠা, process, প্রসেস, comment, কমেন্ট, deliver, ডেলিভার.

Negation list, checked on the whole cue, not just one token: `না`, `নয়`, `নয়`, `লাগবে না`, `বানাবেন না`, `দরকার নেই`, `ছাড়া`, `don't`, `dont`, `without`. A negated cue gets a slash, a cross-out, or a red/lime emphasis on the negated object. It does not get a cheerful checkmark.

## Scene breaks

Start a new scene when any of these is true:

- The cue contains a new index (`02` after `01`, or দ্বিতীয়, আরেকটা, পরের).
- The cue starts with a discourse turn: তাহলে, এরপর, তারপর, এখন, কিন্তু, তবে, তাই, শেষে, মনে রাখবেন, আরেকদিকে, অন্যদিকে.
- The cue is a question and the previous cue was not.
- The cue is a negation pivot and the previous scene was a positive demo.
- A new product or person name appears and the previous scene already had a different product or person as its subject.
- The current scene has already run longer than 8.5 seconds.

Otherwise stay in the scene and **add**. Added atoms remain until the scene ends, unless a later atom in the same scene explicitly replaces the stage (a browser arriving replaces a plain headline; a graph arriving replaces a browser). Replacement rules:

- `browser`, `search`, `progress`, `chat`, `laptop` replace other stage mocks. Pills and badges may stay if they still fit, otherwise they exit 6 frames before the mock enters.
- `graph` replaces mocks.
- A new `headline` replaces the previous headline, not the pills that belong to the new sentence.
- On a scene break, everything except chrome exits over 8 frames. The new scene's first atom enters at the break frame. Overlap those 8 frames. No black flash unless it is the final fade.

## Background shifts

Do not recolor on every scene. Shift the field when:

- the scene index modulo 3 is 0, or
- a discourse turn happened, or
- the theme has a second field color (green-brand uses blue as the second field; pastel uses a cooler wash; dark themes pulse the glow, they do not turn white).

The shift animates over 12 frames. Grid stays. Chrome stays.

## Caption line

Every scene has a caption equal to the cue texts active inside it, joined by a space, max 90 characters. It fades (6 frames) when the active cue changes.

Exceptions:

- If the cue is 1–3 words and those words are already the giant headline, hide the caption so it is not repeated.
- Never show the caption in a default black box with white text. Use the theme's caption skin (file 04).

## Count-up, type, draw, tick

These are not pops. They occupy the token's whole duration.

- Stat: number animates from 0 to the value across `word.start → word.end`. Prefix and suffix (`$`, `%`, `+`, `৳`) are visible the whole time.
- URL or prompt being typed: reveal characters linearly across the cue that contains the typing, about one character per 40–70ms, clamped to the cue.
- Graph edge: stroke-dashoffset animates across 10–16 frames starting at the word that names the relationship (আর, সাথে, ধরে, connect, থেকে).
- Checklist row: the row's check draws at that row's word start. Rows that have not been spoken yet are invisible, not grayed out. Do not show the whole list on the first item.
- Cursor click: cursor is visible from 8 frames before the verb to 10 frames after. Click ripple at the verb frame.
- Button state (Follow → Following): flip at the verb frame, not at scene start.
- Progress bar: fills from the verb frame to the end of that scene, or to the next verb, whichever is sooner.

## Hold and tail

After the last cue, hold the last scene for 18 frames, then either:

- fade to black over 12 frames if the theme is green-brand or either dark theme, or
- cut to the pinned-note CTA card for 36 frames if the last cue is a save/follow/watch line, or if the video is longer than 20 seconds.

Total duration = that tail. If a voiceover file is longer, extend the hold so the audio is not clipped. Duration in frames = `ceil(seconds * 30)`.

## Theme choice

Score the full SRT text. Do not ask the user.

```
green-brand    +3 if text has আপনি / freelancer / ব্যবসা / leads / ফলো
pastel         +3 if text has টুল / AI tool / নতুন / Google / free and a second product
light-diagram  +3 if text has কীভাবে / সিস্টেম / কাজ করে / অটো / এজেন্ট and no numbered list
dark-red       +3 if text has numbered companies or Industry / মডেল / চীন / compare percents
dark-orange    +4 if text has free website / বিকল্প / লাগবে না / no sign-up / ফ্রি টুল
dark-green     +3 if text has এজেন্ট / অফলাইন / ঘুম / এজেন্টই
```

Highest score wins. Tie → green-brand if duration ≤ 55s, else dark-green if "এজেন্ট" is present, else pastel.

Forced `THEME:` line wins over the score.

## Aspect choice

- Forced `ASPECT:` wins.
- green-brand or pastel and duration ≤ 58s → 1080×1920.
- otherwise → 1920×1080.

fps is always 30.

## Brand chrome

Default, because every reference film uses it:

```
name: MARKET X BANGLA
handle: @marketxbangla
kicker: inferred (AI TOOLS / THE AGENT SHIFT / FREE WEBSITES / AI REELS)
```

If `input/brand.json` exists, use it (`name`, `handle`, `kicker` strings). If the SRT contains `@somehandle`, use that handle. Never ask.

## Voiceover

`scripts/prepare.mjs` looks in `input/` for the first file matching `voiceover.*` or any audio extension if there is only one audio file. It copies it to `public/voiceover` keeping the extension and sets `hasVoiceover: true`. The composition plays it from frame 0 with `<Audio>`. No ducking, no music, no TTS.

## Failure rules

- Empty SRT → write a README error and exit prepare with a Bengali message. Do not render a black video and call it done.
- A cue with no classifiable tokens → show it as a headline if it has Bengali, otherwise as a keyword pill. Never drop a cue silently.
- Overlapping atoms must not collide. If a new pill would overlap an old one, stack it 12px below with an 8-frame stagger. Max 4 pills. A 5th pill starts a scene replace.
