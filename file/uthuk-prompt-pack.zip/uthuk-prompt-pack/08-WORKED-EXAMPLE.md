# 08 — Worked example

`example/script.srt` is a reconstruction of the v1 picture, timed the way those frames changed. It is not a claim about the exact spoken audio. Use it as a mapping test. Do not render it unless the human asks for a demo. Their SRT replaces it.

Theme score on this file lands on `green-brand`. Duration is under 58s, so the frame is 1080×1920. Field starts primary green.

Times below are cue times. Atom enter frames are `round(word.start * 30)`.

## Cue by cue

### 0.20–1.10 `আপনি`

- New scene. Recipe R1.
- Frame ~6: headline `আপনি`, white, ~96px. Nothing else on the stage. Brand chip already visible from frame 0.
- Caption hidden (the headline is the whole cue).

### 1.10–2.60 `freelancer নাকি businessman`

- Same scene. No break.
- `freelancer` is a Latin role → pill at ~1.10s, icon laptop, label `FREELANCER`.
- `নাকি` is Bengali glue → not its own object. It may sit in the support line or be dropped.
- `businessman` → second pill at ~1.90s, icon briefcase, stacked under the first.
- Headline `আপনি` stays.

### 2.60–4.40 `leads পাওয়ার একটা shortcut চান`

- `leads` is a Latin payoff noun, not the first word. Recipe R2 at the word `leads` (~2.60s): headline fades over 8 frames, outlined `LEADS` enters.
- `পাওয়ার একটা` stays as a small support line if it fits, or is dropped. Do not make three tiny pills out of glue words.
- `shortcut` → black pill `SHORTCUT` at its own word start (~3.6s).
- `চান` is glue.

### 4.60–6.80 `manus.im এ গিয়ে get started চাপুন`

- Scene break (new product / URL). Previous stage exits over 8 frames.
- `manus.im` → browser atom. Address types `manus.im` across the cue.
- `get started` / `চাপুন` is a click verb → cursor moves to the button and clicks at that word, not at 4.60.

### 6.80–8.20 `FREE 1400 credit পাবেন`

- Same scene. Browser stays.
- `FREE` → badge on the card corner at 6.80.
- `1400` → stat badge `1,400 CREDIT` counting up across the cue. Do not show 1400 on the first frame.

### 8.40–10.40 `সে নিজে leads collect করবে`

- Scene break (discourse is weak here, but a new verb-demo and the  scene would exceed a mock's job). Prefer a break because `collect` changes the verb.
- Progress card. Bar starts filling at `collect`. If you keep `leads` visible, it is a label on the card, not a second outlined word fighting the bar.

### 10.60–13.20 `তাহলে সে নিজে browse করে সঠিক তথ্য এনে দেবে`

- Scene break on `তাহলে`. Field shifts to secondary blue over 12 frames. Chrome stays.
- Headline `তাহলে সে নিজে` at 10.60.
- `browse` is a verb → search card replaces the headline at the verb word. Input types `leads` if that noun is in context, else the noun `তথ্য`.
- Result rows: `সঠিক` and `তথ্য` as two checks at their word starts. Do not show both rows at 10.60.

### 13.20–14.20 `delivered`

- Same scene. Accent bar `DELIVERED` at 13.20, full width of the card. The search results stay above it.

### 14.40–16.80 `এরপর সেই leads ধরে client আর customer পাবেন`

- Scene break on `এরপর`. Field returns to green.
- Recipe R6. Node `LEADS` at the first noun. Edge draws on `ধরে`. Node `CLIENT` at that word. Edge draws on `আর`. Node `CUSTOMER` at that word.
- Person nodes are simple person glyphs, not photos.

### 17.00–18.40 `Market X Bangla ফলো করে রাখুন`

- Scene break. Recipe R16, and because it is a follow CTA it may also be the end card.
- Follow card from 17.00 with button `Follow`.
- Button flips to `Following` at `ফলো` (~17.5s), accent fill.
- After 18.40, hold 18 frames, then fade to `#04140A` over 12 frames.
- Total around 20 seconds plus fade. The example SRT is shorter than the original 43s film. That is fine. Do not pad with empty scenes.

## What a wrong render looks like

- All pills visible at 0.20s. Wrong. `BUSINESSMAN` does not exist yet.
- `DELIVERED` visible during the browse sentence. Wrong. It has its own cue.
- Blue field from frame 0. Wrong. The shift is on `তাহলে`.
- A black subtitle bar with the full cue under a static title. Wrong. That is not these videos.
- `manus.im` as a plain text line and no browser. Wrong. URLs become the mock.
- Following already lit at 17.00. Wrong. The flip is the sync.

## A second, shorter check (v5 grammar)

If the user's SRT is a list of free sites with `লাগবে না`, the plan must be `dark-orange`, 1920×1080 if it runs past 58s, with a chip rail, a browser page per index, a strike-through on the paid tool, and yellow proof tags on `FREE` / `No sign-up`. Do not render that SRT in the green brand system just because it is the default. The score exists so the six references stay distinct.

## A third check (v6 grammar)

Names of people become monogram portraits at the name's frame. A second clause in accent is not on screen during the first clause. A negation gets a slash, not a new happy card. Checklist rows are absent until spoken.
