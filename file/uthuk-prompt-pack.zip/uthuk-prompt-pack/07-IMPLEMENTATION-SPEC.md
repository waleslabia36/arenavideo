# 07 — Implementation spec

Build the project in file 06. This file is how the picture is drawn. Copy the planning approach. Do not simplify it into "show the cue text in the center for the cue duration". That fails the reference.

## scripts/plan.mjs

Write a real planner. Structure:

```js
export function parseSrt(raw) { /* return [{start, end, text}] in seconds */ }

export function buildPlan(raw, opts) {
  const cues = parseSrt(raw).filter(dropNotes);
  // apply ASPECT and THEME notes, strip them
  const theme = forcedTheme || scoreTheme(cues);
  const aspect = forcedAspect || pickAspect(theme, lastEnd(cues));
  const words = cues.flatMap(splitLongCue).flatMap(wordClock);
  const scenes = groupScenes(words, cues);
  const atoms = scenes.flatMap(scene => recipeAtoms(scene, theme));
  // attach atoms onto scenes
  const tail = endTail(cues, theme);
  return {
    width: aspect === "9:16" ? 1080 : 1920,
    height: aspect === "9:16" ? 1920 : 1080,
    fps: 30,
    theme,
    durationInFrames: Math.ceil(tail.end * 30),
    hasVoiceover: Boolean(opts.voiceoverFile),
    voiceoverFile: opts.voiceoverFile || null,
    brand: opts.brand,
    scenes
  };
}
```

`groupScenes` walks cues in order and applies the break rules in file 03. Each scene stores `{ id, start, end, field, caption, cues, words }`. Convert seconds to frames only at the end, with `Math.round(seconds * 30)`, and clamp so `enterFrame < exitFrame`.

`recipeAtoms` implements file 05. It emits atoms with absolute `enterFrame` taken from the word clock, not from the scene start. A pill for the third word enters at that word's frame even if the scene started two seconds earlier.

Minimum mapping you must not skip:

- Bengali-only first word of a scene → `headline` at that word frame.
- Latin role or payoff noun → `pill` at that word frame. The second Latin payoff in a scene may be `blackpill` or `outline` if it is the hit.
- URL → `browser` with `url`, enter at the URL word. Set `verb: "click"` if the same scene has a click/start verb.
- search/browse verb without a URL → `search`, items are the nouns that follow, each item has its own `enterFrame`.
- collect/process verb or a credit number → `progress` plus a `stat` whose `value` counts up. `stat.enterFrame` is the number's frame. The displayed value at frame f is `value * clamp((f - enter) / (end - enter), 0, 1)`.
- two nouns linked by ধরে/আর/থেকে → `graph` with `nodes: [{text, enterFrame}]` and `edges: [{from, to, enterFrame}]`.
- index + name → `index` and a title `headline` or a card title. On dark-orange also emit `chips` for the whole list once the second item exists. Chips stay until the video ends. Active chip is the one whose item scene contains the current frame.
- negation → `ban` or a `strike` flag on the object atom, enter at the negation word.
- follow verb → `follow` atom. `flippedFrame` is the verb frame.
- last CTA or video end → `note` + `polaroid`.
- person name → `portrait` monogram. Initials from Latin capitals, or the first Bengali letter.

Field flag: `primary` or `secondary`. Set `secondary` on scenes that trigger a background shift (file 03). The component lerps colors over 12 frames when the active scene's field changes.

Caption: scene caption string, empty when it would repeat a 1–3 word headline.

## src/fonts.ts

```ts
import { loadFont } from "@remotion/fonts";
import { continueRender, delayRender, staticFile } from "remotion";

const handle = delayRender("fonts");

export const bengali = "Noto Sans Bengali";
export const latin = "Inter";

Promise.all([
  loadFont({ family: bengali, url: staticFile("fonts/noto-sans-bengali-bengali-400-normal.woff2"), weight: "400", format: "woff2" }),
  loadFont({ family: bengali, url: staticFile("fonts/noto-sans-bengali-bengali-600-normal.woff2"), weight: "600", format: "woff2" }),
  loadFont({ family: bengali, url: staticFile("fonts/noto-sans-bengali-bengali-700-normal.woff2"), weight: "700", format: "woff2" }),
  loadFont({ family: latin, url: staticFile("fonts/inter-latin-500-normal.woff2"), weight: "500", format: "woff2" }),
  loadFont({ family: latin, url: staticFile("fonts/inter-latin-700-normal.woff2"), weight: "700", format: "woff2" }),
  loadFont({ family: latin, url: staticFile("fonts/inter-latin-800-normal.woff2"), weight: "800", format: "woff2" })
]).then(() => continueRender(handle)).catch((err) => {
  console.error(err);
  continueRender(handle);
});
```

Match the real filenames that `copy-fonts.mjs` wrote. Do not guess a filename that is not on disk. Import `./fonts` from `Main.tsx` so the delay runs.

## src/theme.ts

Export a `themes` record keyed by the six theme ids. Each value:

```ts
{
  field: "#087B3C",
  fieldAlt: "#184E9A",
  grid: "#066432",
  gridAlt: "#123E7C",
  ink: "#FFFFFF",
  inkOnCard: "#101412",
  accent: "#D8FF4A",
  card: "#FFFFFF",
  glow: "#2EBE62",
  caption: "bar" | "line" | "none",
  handles: boolean,
  mesh: boolean
}
```

Fill every theme from the hex values in file 04. Do not invent a purple gradient.

## src/Main.tsx

```tsx
import { AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import plan from "./generated/plan.json";
import "./fonts";
import { Field } from "./components/Field";
import { Chrome } from "./components/Chrome";
import { Stage } from "./components/Stage";

export const Main = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const scene = activeScene(plan.scenes, frame);
  return (
    <AbsoluteFill>
      <Field theme={plan.theme} field={scene?.field ?? "primary"} frame={frame} />
      <Chrome plan={plan} scene={scene} frame={frame} />
      <Stage plan={plan} scene={scene} frame={frame} fps={fps} />
      {plan.hasVoiceover && plan.voiceoverFile ? (
        <Audio src={staticFile(plan.voiceoverFile)} />
      ) : null}
    </AbsoluteFill>
  );
};
```

`activeScene` returns the scene where `startFrame <= frame < endFrame`. During an 8-frame overlap, render both: the outgoing scene at exit opacity, the incoming scene at enter opacity. Stage.tsx handles that if you pass `frame`.

## Components

### Field

Absolute fill. Background color from theme, lerped when `field` changes. Grid is a repeating linear-gradient, two directions, 1px lines. Glow is a radial-gradient circle whose center is `50% + sin(frame/80)*3%`. On pastel and light-diagram, skip the dark grid and use two mesh radials. The field is always full-bleed under the safe area.

### Chrome

Brand chip position depends on theme (file 04). Text comes from `plan.brand`. Kicker on the opposite side when the theme uses one. Chip rail from a `chips` atom if one is alive at this frame. Caption from the active scene, skinned by `theme.caption`. Hide caption when empty.

### Stage

Map alive atoms (`enterFrame - 2 <= frame <= exitFrame`) to `<Atom>`. Pass `local = frame - enterFrame`. Dead atoms are not mounted. That is what makes the word "rise when it is said".

### Atoms

One file, a switch on `type`. Shared entrance:

```tsx
import { interpolate, spring } from "remotion";

const enter = spring({ frame: local, fps, config: { damping: 14, stiffness: 180, mass: 0.6 } });
const opacity = interpolate(local, [0, 6], [0, 1], { extrapolateRight: "clamp" });
const y = interpolate(enter, [0, 1], [16, 0]);
```

Exit: if `frame > exitFrame - 8`, fade and scale down. Do not unmount before `exitFrame`, or the exit will pop.

Required drawings (simple is fine, empty boxes are not):

- `headline` / `support` — Noto Sans Bengali, the sizes in file 04.
- `pill` / `blackpill` / `badge` — row with an SVG icon circle and the label.
- `outline` — Latin only, accent stroke, transparent fill.
- `stat` — count-up, tabular nums.
- `browser` — chrome dots, address bar revealing `url` by character, a button, optional cursor.
- `search` — input with the keyword, rows whose `enterFrame` has passed get a check. Others are not rendered.
- `progress` — track and fill `clamp((frame - enterFrame) / duration, 0, 1)`.
- `graph` — SVG lines with strokeDashoffset from 1 to 0 after the edge enterFrame. Nodes pop with the spring.
- `follow` — card, button label flips at `flippedFrame`.
- `checklist` — same rule as search rows.
- `compare` — two bars.
- `chat` — characters revealed by `(frame - enterFrame) / fps / 0.05`.
- `portrait` — rounded rect, initials, name.
- `note` + `polaroid` — file 04 CTA. Pin is a small red circle with a 2px stem.
- `ban` — icon plus a circle-slash that draws on.
- `highlight` — box whose border animates via clip or scaleX from 0 to 1.
- `index` — the number, theme-sized.
- `chips` — the rail. Rendered by Chrome, not in the center. Stage can return null for this type if Chrome reads it.
- `bars` — percent comparison.
- `timer` — `m:ss` counting inside the cue.

Cursor is a child of the mock that has `verb`, not its own scene.

Selection handles: if `theme.handles` and local is between 0 and 30, draw four corner SVG paths around the headline. They fade out after frame 30.

## copy-fonts.mjs

```js
import { cpSync, mkdirSync, readdirSync, existsSync } from "node:fs";
import { join } from "node:path";

const out = join("public", "fonts");
mkdirSync(out, { recursive: true });

function take(pkg, tests) {
  const dir = join("node_modules", "@fontsource", pkg, "files");
  if (!existsSync(dir)) throw new Error("Missing " + pkg + ". Did npm install finish?");
  const files = readdirSync(dir);
  let n = 0;
  for (const file of files) {
    if (!file.endsWith(".woff2")) continue;
    if (tests.some((re) => re.test(file))) {
      cpSync(join(dir, file), join(out, file));
      n++;
    }
  }
  if (!n) throw new Error("No woff2 matched in " + pkg);
}

take("noto-sans-bengali", [/bengali-400-normal/, /bengali-600-normal/, /bengali-700-normal/, /latin-400-normal/, /latin-700-normal/]);
take("inter", [/latin-500-normal/, /latin-700-normal/, /latin-800-normal/]);
```

If Inter's files are named `inter-latin-500-normal.woff2`, the regex above matches. Verify by logging the copied names. Point `fonts.ts` at those exact names.

## prepare.mjs

```js
import { readFileSync, writeFileSync, copyFileSync, mkdirSync, readdirSync, existsSync } from "node:fs";
import { join, extname } from "node:path";
import { buildPlan } from "./plan.mjs";

const srtPath = join("input", "script.srt");
if (!existsSync(srtPath)) {
  console.error("input/script.srt নেই। SRT ফাইলটা ওখানে রাখুন।");
  process.exit(1);
}
const raw = readFileSync(srtPath, "utf8");
const audioExt = [".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"];
let voice = null;
if (existsSync("input")) {
  for (const name of readdirSync("input")) {
    if (audioExt.includes(extname(name).toLowerCase())) {
      voice = name;
      break;
    }
  }
}
let voicePublic = null;
if (voice) {
  const ext = extname(voice).toLowerCase();
  voicePublic = "voiceover" + ext;
  mkdirSync("public", { recursive: true });
  copyFileSync(join("input", voice), join("public", voicePublic));
}
let brand = { name: "MARKET X BANGLA", handle: "@marketxbangla", kicker: "AI REELS" };
if (existsSync(join("input", "brand.json"))) {
  brand = { ...brand, ...JSON.parse(readFileSync(join("input", "brand.json"), "utf8")) };
}
const plan = buildPlan(raw, { voiceoverFile: voicePublic, brand });
mkdirSync(join("src", "generated"), { recursive: true });
writeFileSync(join("src", "generated", "plan.json"), JSON.stringify(plan, null, 2));
mkdirSync("out", { recursive: true });
console.log("plan", plan.theme, plan.width + "x" + plan.height, plan.durationInFrames + " frames", voice ? "with voice" : "silent");
```

Kicker inference can live in `buildPlan` and override the default when the score says so. Brand name stays unless `brand.json` or an `@handle` in the SRT says otherwise.

## Stub plan

Ship `src/generated/plan.json` as a 2-second green-brand plan with one headline `উঠুক`, so the file exists before the first prepare. `prepare` replaces it.

## README honesty

If render fails on a missing font file, the error from `copy-fonts.mjs` must name the file. Do not catch and continue into a tofu-text render.

## Do not

- Do not call an LLM API inside the render.
- Do not shell out to Python.
- Do not require ImageMagick, ffmpeg on PATH, or a GPU.
- Do not put the SRT text into `dangerouslySetInnerHTML`.
- Do not animate with CSS transitions. Remotion captures frames. CSS transitions do not run between screenshots. Every motion is a function of `frame`. This is the most common way these projects look static. Springs, interpolates, dashoffsets — all from `frame`.
