# 06 — Render contract

The human will do only this, in Windows PowerShell, from the project folder:

```powershell
npm install
npm run render
```

`npm run render` must create `out/video.mp4` and overwrite it if it exists. Exit code 0 on success.

## package.json

Use exact versions. No `^` and no `~`. Align every `remotion` and `@remotion/*` package to the same version.

```json
{
  "name": "uthuk-render",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "postinstall": "node scripts/copy-fonts.mjs",
    "render": "node scripts/prepare.mjs && remotion render src/index.ts Main out/video.mp4 --codec=h264 --image-format=jpeg --overwrite"
  },
  "dependencies": {
    "@fontsource/inter": "5.2.5",
    "@fontsource/noto-sans-bengali": "5.2.5",
    "@remotion/cli": "4.0.321",
    "@remotion/fonts": "4.0.321",
    "react": "18.3.1",
    "react-dom": "18.3.1",
    "remotion": "4.0.321"
  },
  "devDependencies": {
    "@types/react": "18.3.18",
    "@types/react-dom": "18.3.5",
    "typescript": "5.8.2"
  }
}
```

If 4.0.321 fails to install, pick the newest 4.0.x that does install and pin every Remotion package to that exact version. Do not mix versions. React stays 18.3.1.

`@remotion/bundler` and `@remotion/renderer` come in with `@remotion/cli`. Do not add a second copy at a different version.

## Why these fonts are installed, not fetched at render

`@remotion/google-fonts` downloads slices during render. Noto Sans Bengali is large and has timed out in real renders. Do not use it.

`postinstall` copies woff2 files from `node_modules/@fontsource/.../files/` into `public/fonts/`. `src/fonts.ts` loads those with `@remotion/fonts` and `staticFile()`, and calls `delayRender` until `document.fonts.ready`. Copy at least:

- Noto Sans Bengali bengali subset, weights 400, 600, 700
- Noto Sans Bengali latin subset, weights 400, 700 (so digits and punctuation in that family work)
- Inter latin, weights 500, 700, 800

`copy-fonts.mjs` must not assume bash. Use `node:fs` and `node:path`. If a glob misses, print the files that do exist and copy the closest weights. Fail `postinstall` with a clear error if no Bengali woff2 was copied. A silent fallback to Arial is a failed job.

## Files you must write

```
package.json
tsconfig.json
remotion.config.ts
README.md
input/script.srt
input/PUT-FILES-HERE.txt
public/fonts/            (filled by postinstall)
src/index.ts
src/Root.tsx
src/fonts.ts
src/Main.tsx
src/theme.ts
src/components/Field.tsx
src/components/Chrome.tsx
src/components/Stage.tsx
src/components/Atoms.tsx
src/generated/plan.json  (stub, overwritten by prepare)
scripts/copy-fonts.mjs
scripts/prepare.mjs
scripts/plan.mjs
```

`scripts/plan.mjs` exports `buildPlan(srtText, opts)`. `scripts/prepare.mjs` reads `input/script.srt`, finds an optional voiceover, calls `buildPlan`, writes `src/generated/plan.json`, copies the voiceover to `public/voiceover.<ext>`.

The stub `plan.json` must be valid so a cold TypeScript check does not crash. `prepare` overwrites it before every render.

## tsconfig.json

```json
{
  "compilerOptions": {
    "target": "ES2018",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "strict": true,
    "skipLibCheck": true,
    "resolveJsonModule": true,
    "esModuleInterop": true,
    "noEmit": true
  },
  "include": ["src"]
}
```

## remotion.config.ts

```ts
import { Config } from "@remotion/cli/config";

Config.setOverwriteOutput(true);
Config.setVideoImageFormat("jpeg");
Config.setCodec("h264");
```

## src/index.ts

```ts
import { registerRoot } from "remotion";
import { RemotionRoot } from "./Root";

registerRoot(RemotionRoot);
```

## src/Root.tsx

Read width, height, fps, durationInFrames from `src/generated/plan.json`.

```tsx
import { Composition } from "remotion";
import plan from "./generated/plan.json";
import { Main } from "./Main";

export const RemotionRoot = () => {
  return (
    <Composition
      id="Main"
      component={Main}
      durationInFrames={plan.durationInFrames}
      fps={plan.fps}
      width={plan.width}
      height={plan.height}
    />
  );
};
```

The composition id is `Main`. The render command uses that id. Do not rename it.

## Audio

If `plan.hasVoiceover` is true:

```tsx
import { Audio, staticFile } from "remotion";

<Audio src={staticFile(plan.voiceoverFile)} />
```

`voiceoverFile` is like `voiceover.mp3`, relative to `public/`. If false, render no `<Audio>`. Do not generate silence with ffmpeg. A video with no audio track is correct.

## Windows

- `npm run render` uses npm's script runner, so `&&` is fine. Do not tell the human to run `bash`.
- Paths in scripts go through `path.join`. Never hardcode `/home` or `C:\\`.
- `out/` does not need to exist beforehand; Remotion creates it. If it does not, `prepare.mjs` does `fs.mkdirSync("out", { recursive: true })`.
- No `rm`, no `cp`, no shell globs in npm scripts.
- First render downloads Chrome. README must say the first run needs internet and can take several minutes. Later runs are offline except that Chrome is already cached.

## README.md (Bengali, short)

Tell them:

1. `input/script.srt` এ SRT রাখুন। ভয়েসওভার থাকলে `input/voiceover.mp3` (wav/m4a চলবে)।
2. PowerShell এ এই ফোল্ডারে:
   ```powershell
   npm install
   npm run render
   ```
3. ভিডিও: `out/video.mp4`.
4. প্রথমবার ইন্টারনেট লাগবে (Chrome ডাউনলোড)। Node 18 বা তার উপরে লাগবে.
5. রং বা সাইজ বদলাতে চাইলে SRT-এর প্রথম লাইনে `ASPECT: 9:16` বা `THEME: dark-green` রাখা যায়। না রাখলে সিস্টেম নিজে নেবে। এই লাইনগুলো স্ক্রিনে আসবে না।

Do not write a long English essay in the README.

## plan.json shape

```json
{
  "width": 1080,
  "height": 1920,
  "fps": 30,
  "theme": "green-brand",
  "durationInFrames": 600,
  "hasVoiceover": false,
  "voiceoverFile": null,
  "brand": { "name": "MARKET X BANGLA", "handle": "@marketxbangla", "kicker": "AI REELS" },
  "scenes": [
    {
      "id": "s0",
      "startFrame": 0,
      "endFrame": 150,
      "field": "primary",
      "caption": "",
      "atoms": [
        {
          "id": "a0",
          "type": "headline",
          "text": "আপনি",
          "enterFrame": 6,
          "exitFrame": 140,
          "verb": null
        }
      ]
    }
  ]
}
```

Frames are absolute, from 0. `enterFrame` is absolute too, not local. The component converts to local with `frame - enterFrame`.

Atom `type` is one of: `headline`, `support`, `pill`, `blackpill`, `outline`, `badge`, `stat`, `browser`, `search`, `progress`, `graph`, `follow`, `checklist`, `compare`, `chat`, `timer`, `portrait`, `chips`, `note`, `polaroid`, `ban`, `bars`, `highlight`, `index`.

Extra fields are allowed (`items`, `value`, `prefix`, `suffix`, `url`, `from`, `to`, `checked`, `page`). Keep them JSON-serializable.

## Determinism

No `Math.random` in render. No `Date.now`. Glow drift is `Math.sin(frame / 80)`. The same SRT must produce the same frames. This matters because the human will re-render.

## Performance

1080×1920 or 1920×1080, jpeg frames, h264, crf default. Do not render 4K. Do not enable motion blur on every element every frame — only on the outgoing group during an 8-frame replace. A 60-second vertical video should render in a few minutes on a normal PC, not hours.
