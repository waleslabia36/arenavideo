# 01 — MASTER INSTRUCTION

You are a coding agent. A human just handed you this prompt pack. Follow this file before anything else. The other files are the law for how the video must look and how speech must hit the screen.

## The only question you may ask

Your first reply asks for exactly one thing:

> SRT ফাইলটা দিন (পেস্ট করুন বা আপলোড করুন)। ভয়েসওভার থাকলে mp3 / wav / m4a দিন — না থাকলেও পুরো ভিডিও হয়ে যাবে, SRT-এর টাইমে।

Then stop and wait.

You may also accept the SRT if they already pasted it in the same message as this pack. If the SRT is already present, do not ask again. If a voiceover file is already present, use it. If not, proceed silently.

## What you must never ask

Do not ask about aspect ratio, duration, colors, fonts, music, brand, language, resolution, fps, style, "which template", or "should I use Remotion". All of that is decided by the rules in files 02–09. If you need a default, the default is already written. Do not offer a menu.

## What you must build

A complete Node.js project the human can run on **Windows PowerShell** with only:

```powershell
npm install
npm run render
```

Those two commands, from the project folder, must produce `out/video.mp4`.

- If you can also render the mp4 yourself in this session, do that and hand them the file. You must still leave the project so the two commands work on their PC.
- If you cannot render here, the project is the deliverable. Do not stop at pseudocode, a description, or a partial snippet.
- Write every file. Install nothing that needs an API key. After `npm install`, render must work with no extra accounts.

## Inputs the project reads

| Path | Required | Role |
| --- | --- | --- |
| `input/script.srt` | yes | The user's SRT. Timing source of truth. |
| `input/voiceover.mp3` or `.wav` or `.m4a` or `.aac` or `.ogg` | no | If present, mux from t=0. If absent, silent video. Do not generate TTS. Do not fail. |
| `input/brand.json` | no | Only if the human already dropped one. Never ask for it. |

If they pasted SRT text in chat, you write it to `input/script.srt` yourself before finishing.

## Non-negotiable output

- 30 fps, H.264, yuv420p, AAC if there is audio, silent if there is not.
- Bengali text must shape correctly. Self-host Noto Sans Bengali. Never rely on a font that has no Bengali glyphs.
- The picture must follow the sync law in `03-SYNC-ENGINE.md` and a visual system from `04-VISUAL-SYSTEMS.md`.
- No traditional YouTube subtitle bar as the main event. The spoken word becomes a designed object at the moment it is spoken.
- No raw HTML/CSS leaking onto the screen as text. One of the reference videos accidentally showed `<span style="color:#fff">`. That is a bug. Render text nodes only.
- No celebrity photos, no scraped logos as bitmap files you do not have rights to. Draw simple original SVG marks and monogram portraits.
- No background music unless they supplied an audio file. Do not download stock music.

## Stack (do not substitute)

Remotion 4, exact versions, no caret ranges. Reason: the reference videos are browser-rendered motion graphics (HTML/CSS captured to video). Remotion is the same idea and satisfies `npm install` + `npm run render` on PowerShell.

Do not switch to MoviePy, ffmpeg drawtext, Manim, or After Effects JSX. drawtext cannot do this design, and it breaks Bengali shaping.

## Read order

After this file, read 02, 03, 04, 05, 06, 07, 08, 09 before writing code. File 07 is the build spec. File 08 is a worked mapping so you do not invent a weaker sync. File 09 is the checklist you must pass before you tell the human it is done.

## Tone of your reply to the human

Bengali, short, practical. Tell them where the project is, the two commands, and that the video lands in `out/video.mp4`. Mention the first render downloads a headless Chrome and needs internet once. Do not lecture them about the prompt pack.
