# 02 — What the six videos actually do

These notes come from watching every file in https://github.com/waleslabia36/arenavideo frame by frame (1 fps filmstrips, keyframes, color timelines, silence detection). Do not invent a different style. Match this grammar.

## The one law

Speech is the clock. A phrase is spoken, and the thing that phrase names appears on screen at that moment — not earlier as a title card, not later as a caption catch-up.

It is not karaoke. The full sentence is not dumped as a bottom subtitle and left there. The sentence is **interpreted**:

- Bengali subject → giant type
- English keyword or product name → pill, logo chip, outlined display word
- Number, price, percent → badge or count-up
- Action (browse, collect, follow, generate, click) → a UI mock that performs the action
- A list → rows that tick in one by one as each item is named
- A relationship → a line that draws between nodes
- A negation → a slash, a cross-out, a red word
- A new step → the center stage replaces, the brand chrome stays

Within one idea, elements **accumulate**. When the idea is finished and the voice turns, the center **replaces** (crossfade, slight scale, sometimes motion blur). The background hue shifts only on a real section change, not on every sentence.

## What is always on screen

- A small brand chip. In these videos: `MARKET X BANGLA` or `Market-X Bangla BD`, plus sometimes a right-side kicker (`AI TOOLS`, `THE AGENT SHIFT`).
- One focal cluster. Never a wall of paragraphs.
- Often a designed caption of the current spoken line, smaller than the focal cluster, at the bottom or inside a banner. The caption is part of the design (lime bar, white line, gray line), not a default subtitle skin.
- Generous margin, about 7% safe area.
- A background that is never dead flat: grid, mesh gradient, or a slow glow.

## What never happens

- Hard jump cuts every second. Scene detection at threshold 0.28 found almost no cuts. Transitions are animated.
- A static bullet slide that appears all at once while the voice reads it.
- Random stock b-roll unrelated to the word being said.
- Lower-third name straps as the only text treatment.
- The same layout held for 15 seconds.

## Timing texture, measured

Speech is almost continuous. Silence detection at −32 dB only found short gaps (0.3–0.8s) and end tails. A music bed or room tone fills the gaps, so you cannot sync off silence. Sync off the SRT.

Observed beat lengths:

- Word-add (a pill, a name, a badge): about 0.6–1.4s, then it stays.
- UI demonstration (browser, search results filling, progress bar): 2–4s, and the UI animates across that whole window, not in one pop.
- Section color shift: held for several seconds (v1 goes green for ~24s, blue for ~6s, green again).
- End: fade to black or a CTA card in the last 1–2s. v1 is black from ~36s to 42.9s after the last point.

## The six films

### v1 — green brand pitch — 720×1280 — 42.9s

Background `#087B3C`-family green with a darker grid and soft blooms. Around 24–31s the field shifts to blue `#1A4FA0`-family, then returns to green. Top-center white pill: green rounded square + `MARKET X BANGLA`.

Build, in order, as the voice walks the sentence:

1. Giant white `আপনি`.
2. White pill `FREELANCER` with a small icon.
3. White pill `BUSINESSMAN` under it.
4. A smaller Bengali clause under the pills.
5. Giant lime-outlined `LEADS`, black pill `SHORTCUT`. Previous headline fades. This is a replacement inside the same idea, not a cut.
6. A browser card types / reveals `manus.im`, a cursor clicks "Get started", then `FREE` and `1,400 CREDIT` badges pop.
7. The card is replaced by a collect card: checklist ticks, a progress bar fills, numbers `1,500` / `2,000` count.
8. A target diagram: concentric rings, black bar `TARGETED AUDIENCE`, an input that says `leads`.
9. Blue shift. Headline `তাহলে সে নিজে`, lime pill `browse করে`, a search card types `leads`, rows check off, a lime bar says `DELIVERED`.
10. Node diagram draws itself: `LEADS` connects to person icons as client/customer are named.
11. Comment / video UI.
12. A follow card. The button flips from Follow to Following on the word.
13. Fade to black.

Signature: English keywords are objects. Bengali is the sentence skeleton. The UI does the verb.

### v2 — light diagram — 1280×720 — 92.8s

Mostly white / pale mint / pale blue. Not the green brand field. Center is a diagram: concentric rings, a brain or agent node, black rounded icon chips (folder, sync, clipboard) connected by thin curves. Bottom line mixes Bengali with one English word set in the same sentence (`boring`). Later frames go nearly white with a single green circle motif, then a brief dark-green flash around 39s, then back to light. Long, calm, additive. Use this system when the SRT is a "how it works" explanation rather than a tool roundup or a personal pitch.

### v3 — pastel product roundup — 720×1280 — 51.8s

Soft white field with ice-blue and blush radial washes. Header: `MARKET X BANGLA` left, `AI TOOLS` right. Footer handle `@marketxbangla`.

- Hook: `নতুন দুইটা AI`.
- `01` Google Vids. Play button, `FREE` and `$0` pills, a launch bar, a cursor.
- Floating cards `Video` and `Cartoon` with colored icon tiles; a check pops on the one being named.
- `02` Lumen5. A sign-up form, then feature cards (idea / points / ad) and a `−50%` badge.
- A chat field types a prompt while that sentence is spoken.
- "Generating" cards, a `1:00` timer.
- A comparison: Lumen5 vs InVideo.

Signature: numbered tools, price pills, cursor, typing, pastel cards with colored icon squares (teal, magenta, orange, blue). White cards, 22–28px radius, soft shadow.

### v4 — dark red listicle — 1280×720 — 82.6s

Near-black with a red glow and a faint grid. Red is the only accent.

- `AI Industry` with the English word in red, Bengali `এখন অনেক বড়`.
- A small person card and a computer label with a progress bar.
- `টিকে থাকতে হলে` in red, a shield icon, the word `জানে`.
- `01 Sakana` inside Figma-style selection handles (four corner brackets). Orbital lines draw out to ChatGPT, Claude, Gemini, and a report card.
- Motion-blur transition into `02 Deep Seek` (whale mark, country chip). Comparison bars: one tool at 100%, another lower.
- `03 Qwen`, a laptop mock, coding comparison bars.

Signature: big index number, selection handles on the active title, connection lines, percent bars, motion blur between numbers.

### v5 — dark orange tool walkthrough — 1280×720 — 127.1s

Near-black, orange glow `#FF4D1C`. A practical "these sites replace paid tools" video.

- Title `04 Free Websites` and four tool cards.
- A paid subscription (Photoshop-style) is crossed out. Bengali `লাগবে না`.
- Then one tool at a time: `01 Duck.ai`, `02 Photopea`, `03 Cobalt.tools`, `04 Napkin`.
- Each tool is a browser mock. The cursor moves and the page changes as the steps are spoken. Bengali caption sits under the mock.
- Yellow highlight tags on the proof words: `AI`, `100% Free`, `No sign-up`.
- A persistent bottom rail of all four names. The active chip is orange.
- End card: `চারটা টুলই FREE`, the four marks, and a save CTA (`এখনই save করে রাখো`) with the Market X Bangla chip.

Signature: mock browser is the stage, bottom chip rail, cross-out for the paid thing, yellow tag for the English proof word.

### v6 — dark green editorial — 1280×720 — 39.3s

Dark green grid `#06381F` to `#0A4A28`, lime accent. Header: `Market-X Bangla BD` left, `THE AGENT SHIFT` right.

- Names arrive with portrait cards: স্যাম অল্টম্যান, ইলন মাস্ক, মার্ক জাকারবার্গ. Use monogram portraits, not real photos.
- Lines draw into an org chart labeled with product words (DOTS, OPEN BOTS, MUSE). One of those words sits in a selection box.
- A highlight box closes around the key clause (`একই দিকে`).
- A monitor mock: `PERSONAL COMPUTER`, robot/agent mark, `AGENT ACTIVE`.
- Hub-and-spoke: phone in the center, app icons around it, while the voice says the apps.
- Two-line lockup. The second line is the hit: `আপনি অফলাইনে।` then `কাজ চলছে।` in green.
- A checklist fills (`Summarizing inbox`, `Processing tasks`, `Sending results`) and a `24/7` badge pops.
- A big stat `3,580+`.
- Negation: `আরেকটা অ্যাপ? বানাবেন না।` with a prohibition slash over a `NEW APP` icon.
- A flow of nodes, then `এজেন্টই সব সামলাবে।`
- End beat: connectors and plugins as small icon chips.

Signature: portrait + name on the spoken name, highlight box on the clause that matters, checklist ticks, prohibition, big stat.

## A layout the channel also uses

A green grid CTA card: giant faded numerals in the background (28 29 30 31), a white note pinned with a red pin, one Bengali line in green (`ভিডিওগুলো দেখো`), a small polaroid (clapper, `AI REELS`). Use this for short CTA cues: watch, save, follow, remember, "আগে দেখো".

## Audio

AAC HE-AAC, stereo, ~60 kb/s, 44.1 kHz. Voice is the master. Do not invent a music bed. If the user supplies a voiceover, mux it from the first sample and do not time-stretch the pictures to the waveform. The SRT is the clock. If the voiceover is longer than the last cue, hold the last scene. If it is shorter, let the video finish on the SRT. If there is no voiceover, the video is silent and still complete.
