# 09 — QA checklist

Run this before you tell the human the project is ready. If a line fails, fix it. Do not hand over a project that only typechecks.

## Project

- [ ] `npm install` then `npm run render` are the only commands in the README.
- [ ] Both commands work in PowerShell. No bash, no `export`, no `&&` the human must type themselves.
- [ ] Remotion packages are the same exact version. No caret.
- [ ] `input/script.srt` is the human's SRT, not the example, unless they asked for the example.
- [ ] Missing SRT makes `prepare` exit 1 with a Bengali line. It does not render the stub plan.
- [ ] A voiceover in `input/` is copied to `public/` and muxed. No voiceover still renders.
- [ ] No TTS, no API key, no music download.
- [ ] `out/video.mp4` is the path you tell them.

## Fonts

- [ ] `public/fonts` contains Noto Sans Bengali woff2 files after install.
- [ ] A frame with `আপনি` shows real Bengali shapes, not boxes, not a Latin fallback that drops vowel signs.
- [ ] Fonts load from `staticFile`, not from Google at render time.

## Sync (open the video, scrub)

Pick three cues from their SRT at random.

- [ ] 2 frames before the cue, its new noun is not on screen.
- [ ] 8 frames after that noun's estimated start, the noun is on screen and has moved since frame 0 of its entrance (scale or Y is not stuck at the rest pose on frame 0).
- [ ] A later word in the same idea appears while the earlier word is still there.
- [ ] The next scene removes the old stage instead of stacking forever.
- [ ] A number counts. It is not born at its final value.
- [ ] A URL or prompt types. It is not born fully written.
- [ ] A list row is invisible until its word.
- [ ] A follow button flips at the verb, not at scene start.
- [ ] The caption does not repeat a one-word headline.
- [ ] No cue was dropped.

## Picture

- [ ] Theme matches the score in file 03, or the forced `THEME:` line.
- [ ] Aspect matches file 03, or the forced `ASPECT:` line.
- [ ] Colors are the ones in file 04, not a default purple SaaS gradient.
- [ ] Brand chip is visible and not jumping every cue.
- [ ] Safe margins hold. Nothing clips the frame edge.
- [ ] At most one mock, one headline, four pills.
- [ ] Dark-red or dark-green titles get selection handles for ~30 frames.
- [ ] Dark-orange lists get a chip rail and a light page inside a dark browser.
- [ ] Negation is a slash, a strike, or accent text. Not a checkmark.
- [ ] End hold exists. The video does not cut on the last spoken frame.
- [ ] No raw HTML, no `{word.start}`, no `undefined`, no `[object Object]` on screen.
- [ ] No remote images. Portraits are monograms.
- [ ] Motion is a function of `frame`. You did not use CSS transitions.

## Text

- [ ] Bengali line breaks are on spaces.
- [ ] No word is truncated with an ellipsis if it was spoken.
- [ ] Latin payoff nouns are pills or outline, not the same weight as the Bengali headline, unless the theme is light-diagram and the spec says inline.
- [ ] `ASPECT:` and `THEME:` notes are not burned into the picture.

## Before the reply

- [ ] You ran `npm install` and `npm run render` yourself if this environment allows it, and you watched at least five frames from different seconds.
- [ ] If you could not render here, you still wrote every file in file 06 and the scripts are complete, not stubs.
- [ ] Your Bengali reply names the folder, the two commands, `out/video.mp4`, and the first-run Chrome download. Nothing else long.

If the scrub test fails, the video is not done. The human asked for the word to rise when it is said. That is the product.
